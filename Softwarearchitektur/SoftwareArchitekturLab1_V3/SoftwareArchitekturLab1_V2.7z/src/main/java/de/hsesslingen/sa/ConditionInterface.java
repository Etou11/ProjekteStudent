package de.hsesslingen.sa;

public interface ConditionInterface
{
	public String attackNoise();
	public String movementNoise();
}
