package de.hsesslingen.sa;

public class Dekorierer implements ConditionInterface
{
	public String arg;

	public Dekorierer(String arg)
	{
		this.arg = arg;
	}

	@Override
	public String attackNoise()
	{
		switch (this.arg)
		{
		case "müder":
			return "Zzz...";
		case "hungriger":
			return "Grumml..";
		case "verwundeter":
			return "Autsch!";
		case "vergifteter":
			return "Buah..";
		default:
			return null;
		}
	}

	@Override
	public String movementNoise()
	{
		switch (this.arg)
		{
		case "müder":
			return "Gähn..";
		case "hungriger":
			return "Grrmbl..";
		case "verwundeter":
			return "Aua..";
		case "vergifteter":
			return "Ugh..";
		default:
			return null;
		}
	}
}
