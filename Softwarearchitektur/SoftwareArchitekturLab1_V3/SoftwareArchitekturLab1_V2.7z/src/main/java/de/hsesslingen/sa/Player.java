package de.hsesslingen.sa;

import java.util.List;

public class Player implements ConditionInterface
{
	String race;
	List<Dekorierer> decoList;
	
	public Player(String race, List<Dekorierer> decoList)
	{
		this.race = race;
		this.decoList = decoList;
	}
	
	public String movementNoise()
	{
		switch (this.race)
		{
		case "Mensch":
			return "Gehe nach ";
		case "Orc":
			return "Drod ";
		case "Oger":
			return "Grunz ";
		case "Drache":
			return "Schwing ";
		default:
			return null;
		}
	}

	public String attackNoise()
	{
		switch (this.race)
		{
		case "Mensch":
			return "Angriff!!";
		case "Orc":
			return "Adog!!";
		case "Oger":
			return "Waah!!";
		case "Drache":
			return "Fauch!!";
		default:
			return null;
		}
	}
	
	public void attack()
	{
		StringBuilder sb = new StringBuilder();
		
		for(Dekorierer ele : decoList)
		{
			sb.append(ele.attackNoise() + " ");
		}
		sb.append(this.attackNoise());
		Console.writeLine(sb.toString());
	}
	
	public void move(String input)
	{
		StringBuilder sb = new StringBuilder();
		String[] split = input.split(" ");
		
		for(Dekorierer ele : decoList)
		{
			sb.append(ele.movementNoise() + " ");
		}
		sb.append(this.movementNoise());
		
		sb.append(split[split.length - 1]);
		Console.writeLine(sb.toString());
	}
	
}
